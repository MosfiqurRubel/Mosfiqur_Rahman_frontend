1. Install RubyGems - https://rubygems.org/pages/download
2. Install Sass - http://sass-lang.com/install
3. Compass - http://compass-style.org/install/
