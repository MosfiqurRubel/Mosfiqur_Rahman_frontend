(function ($) {
    $('.tabs .tab-nav a').on('click', function (e) {
        e.preventDefault();
        var currentAttrValue = $(this).attr('href');
        $('.tabs ' + currentAttrValue).show(500).siblings().hide(500);
        $(this).parent('li').addClass('active').siblings().removeClass('active');
    });

    // TOGGLE HAMBURGER & COLLAPSE NAV
    $('.toggle-menu').on('click', function () {
        $(this).toggleClass('active');
        $('.nav').toggleClass('collapse');
    });
    // REMOVE X & COLLAPSE NAV ON ON CLICK
    $('.nav a').on('click', function () {
        $('.nav-toggle').removeClass('active');
        $('.nav').removeClass('collapse');
    });

}(jQuery));